<?php $__env->startSection('title'); ?>
    <?php echo e(helperTrans('admin.Doctor Branches Times')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex align-items-center">
            <h5 class="card-title mb-0 flex-grow-1"><?php echo e(helperTrans('admin.Times For Doctor Branches')); ?> <?php echo e($doctor->name); ?></h5>
            <div>
                <button id="addNewRow" class="btn btn-primary"> <?php echo e(helperTrans('admin.Add New Time')); ?></button>
            </div>

        </div>
        <form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('admin.update_doctor_branches_times',$doctor->id)); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body" id="containerData">
                <?php $__currentLoopData = $doctorTimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctorTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" id="row_<?php echo e($doctorTime->id); ?>">
                        <div class="card-header text-center">
                            <span data-id="<?php echo e($doctorTime->id); ?>" class="text-center text-danger deleteRow" style="cursor: pointer"><i class="fa fa-trash"></i></span>
                        </div>
                        <div class="card-body">
                            <div class="row g-4">
                                <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                                    <!--begin::Label-->
                                    <label for="day_id_<?php echo e($doctorTime->id); ?>"
                                           class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                        <span class="required mr-1"><?php echo e(helperTrans('admin.Day')); ?> <span class="red-star">*</span></span>
                                    </label>
                                    <!--end::Label-->
                                    <select required name="day_id[]" id="day_id_<?php echo e($doctorTime->id); ?>"
                                            class="form-control">
                                        <option selected disabled>Select Day</option>

                                        <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($day->id==$doctorTime->day_id): ?> selected
                                                    <?php endif; ?> value="<?php echo e($day->id); ?>"><?php echo e($day->day); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="d-flex flex-column mb-7 fv-row col-sm-3">
                                    <!--begin::Label-->
                                    <label for="from_time_<?php echo e($doctorTime->id); ?>"
                                           class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                        <span class="required mr-1"><?php echo e(helperTrans('admin.From Time')); ?> <span
                                                class="red-star">*</span></span>
                                    </label>

                                    <input type="time" class="form-control" id="from_time_<?php echo e($doctorTime->id); ?>"
                                           name="from_time[]" value="<?php echo e($doctorTime->from_time); ?>">

                                </div>

                                <div class="d-flex flex-column mb-7 fv-row col-sm-3">
                                    <!--begin::Label-->
                                    <label for="to_time_<?php echo e($doctorTime->id); ?>"
                                           class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                        <span class="required mr-1"><?php echo e(helperTrans('admin.To Time')); ?> <span
                                                class="red-star">*</span></span>
                                    </label>

                                    <input type="time" class="form-control" id="to_time_<?php echo e($doctorTime->id); ?>"
                                           name="to_time[]" value="<?php echo e($doctorTime->to_time); ?>">

                                </div>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="text-center mb-4">
                    <button form="form" type="submit" id="submit" class="btn btn-outline-primary"><?php echo e(helperTrans('admin.Update')); ?></button>
                </div>
            </div>

       

        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

    <script>
        $(document).on('click', '.deleteRow', function () {

            var row_id = $(this).attr('data-id');

            $(`#row_${row_id}`).remove();

        })
    </script>

    <script>
        $(document).on('click', '#addNewRow', function () {


            var random = Math.floor(Math.random() * (999999999999 - 999 + 1)) + 999999999;

            var html = `


                    <div class="card" id="row_${random}">
                        <div class="card-header text-center">
                            <span data-id="${random}" class="text-center text-danger deleteRow" style="cursor: pointer"><i  class="fa fa-trash"></i></span>
                        </div>
                        <div class="card-body">


                            <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                                <!--begin::Label-->
                                <label for="day_id_${random}" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                    <span class="required mr-1"><?php echo e(helperTrans('admin.Day')); ?> <span class="red-star">*</span></span>
                                </label>
                                <!--end::Label-->
                                <select required name="day_id[]" id="day_id_${random}" class="form-control">
                                    <option selected disabled>Select Day</option>

                                    <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option  value="<?php echo e($day->id); ?>"><?php echo e($day->day); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>




                            <div class="d-flex flex-column mb-7 fv-row col-sm-3">
                                <!--begin::Label-->
                                <label for="from_time_${random}" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                    <span class="required mr-1"><?php echo e(helperTrans('admin.From Time')); ?> <span class="red-star">*</span></span>
                                </label>

                                <input type="time" class="form-control" id="from_time_${random}" name="from_time[]" value="">

                            </div>


                            <div class="d-flex flex-column mb-7 fv-row col-sm-3">
                                <!--begin::Label-->
                                <label for="to_time_${random}" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                    <span class="required mr-1"><?php echo e(helperTrans('admin.To Time')); ?> <span class="red-star">*</span></span>
                                </label>

                                <input type="time" class="form-control" id="to_time_${random}" name="to_time[]" value="">

                            </div>

                        </div>
                    </div>

                    </div>
                



            `;

            $('#containerData').append(html);


        });

    </script>


    <script>
        $(document).on('submit', "form#form", function (e) {
            e.preventDefault();

            var formData = new FormData(this);

            var url = $('#form').attr('action');
            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                beforeSend: function () {


                    $('#submit').html('<span class="spinner-border spinner-border-sm mr-2" ' +
                        ' ></span> <span style="margin-left: 4px;"><?php echo e(helperTrans('admin.Work is underway')); ?></span>').attr('disabled', true);
                },
                complete: function () {
                },
                success: function (data) {

                    window.setTimeout(function () {

// $('#product-model').modal('hide')
                        if (data.code == 200) {
                            toastr.success(data.message)
                            $('#submit').html('Update').attr('disabled', false);

                        } else {
                            toastr.error(data.message)
                            $('#submit').html('<?php echo e(helperTrans('admin.Update')); ?>').attr('disabled', false);

                        }
                    }, 1000);


                },
                error: function (data) {
                    $('#submit').html('Update').attr('disabled', false);
                    if (data.status === 500) {
                        toastr.error('<?php echo e(helperTrans('admin.there is an error')); ?>')
                    }

                    if (data.status === 422) {
                        var errors = $.parseJSON(data.responseText);

                        $.each(errors, function (key, value) {
                            if ($.isPlainObject(value)) {
                                $.each(value, function (key, value) {
                                    toastr.error(value)
                                });

                            } else {

                            }
                        });
                    }
                    if (data.status == 421) {
                        toastr.error(data.message)
                    }

                },//end error method

                cache: false,
                contentType: false,
                processData: false
            });
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.inc.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/doctorBranch/times.blade.php ENDPATH**/ ?>