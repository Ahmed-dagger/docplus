<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('cities.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row g-4">


        <?php $__currentLoopData = languages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                <!--begin::Label-->
                <label for="name_<?php echo e($language->abbreviation); ?>" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                    <span class="required mr-1"><?php echo e(helperTrans('admin.name')); ?>(<?php echo e($language->abbreviation); ?>)</span>
                    <span class="red-star">*</span>
                </label>

                <!--end::Label-->
                <input id="name_<?php echo e($language->abbreviation); ?>" required type="text" class="form-control form-control-solid"
                       placeholder="" name="name[<?php echo e($language->abbreviation); ?>]" value=""/>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        <div class="d-flex flex-column mb-7 fv-row col-sm-12">
            <!--begin::Label-->
            <label for="governorate_id" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Governorate')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <select name="governorate_id" id="governorate_id" class="form-control">
                <option selected disabled>Select governorate</option>
                <?php $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($governorate->id); ?>"><?php echo e($governorate->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>










    </div>
</form>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/city/parts/create.blade.php ENDPATH**/ ?>