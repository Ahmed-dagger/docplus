
<!-- JAVASCRIPT -->
<script src="<?php echo e(url('assets')); ?>/dashboard/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/libs/simplebar/simplebar.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/libs/node-waves/waves.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/libs/feather-icons/feather.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/js/pages/plugins/lord-icon-2.1.0.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/js/plugins.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/js/jquery.fancybox.min.js"></script>

<!-- apexcharts -->


<!-- Vector map-->



<!--Swiper slider js-->


<!-- Dashboard init -->



<!-- App js -->
<script src="<?php echo e(url('assets')); ?>/dashboard/js/app.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/js/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/js/pages/sweetalerts.init.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/libs/apexcharts/apexcharts.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/backEndFiles/alertify/alertify.min.js"></script>


<script>
    $(document).ready(function () {
        $('.dropify').dropify();
    });
</script>


<script>
    $('.lds-hourglass').fadeOut(1000)
    $.ajaxSetup({
        headers:
            { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
    });
    $(document).on('keyup','.numbersOnly',function () {
        this.value = this.value.replace(/[^0-9\.]/g,'');
    });
</script>









<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/layouts/assets/js.blade.php ENDPATH**/ ?>