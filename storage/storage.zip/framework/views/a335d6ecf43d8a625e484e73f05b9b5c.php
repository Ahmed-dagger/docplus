<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('sub_specializations.update',$row->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-4">


        <input type="hidden" name="id" value="<?php echo e($row->id); ?>">


        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <label for="image" class="form-control-label"><?php echo e(helperTrans('admin.image')); ?> </label>
            <input id="image" type="file" class="dropify" name="image" data-default-file="<?php echo e(get_file($row->image)); ?>" accept="image/*"/>
            <span
                class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
        </div>

        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <label for="icon" class="form-control-label"><?php echo e(helperTrans('admin.Icon')); ?> </label>
            <input id="icon" type="file" class="dropify" name="icon" data-default-file="<?php echo e(get_file($row->icon)); ?>" accept="image/*"/>
            <span
                class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
        </div>



    <?php $__currentLoopData = languages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                <!--begin::Label-->
                <label for="name_<?php echo e($language->abbreviation); ?>" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                    <span class="required mr-1"><?php echo e(helperTrans('admin.name')); ?>(<?php echo e($language->abbreviation); ?>)</span>
                    <span class="red-star">*</span>
                </label>

                <!--end::Label-->
                <input id="name_<?php echo e($language->abbreviation); ?>" required type="text" class="form-control form-control-solid"
                       placeholder="" name="name[<?php echo e($language->abbreviation); ?>]" value="<?php echo e($row->getTranslation('name', $language->abbreviation)); ?>"/>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <div class="d-flex flex-column mb-7 fv-row col-sm-12">
            <!--begin::Label-->
            <label for="color" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Color')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <input type="color" id="color" class="form-control" name="color" value="<?php echo e($row->color); ?>">
        </div>


    </div>
</form>

<script>
    $('.dropify').dropify();

</script>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/subSpecialization/parts/edit.blade.php ENDPATH**/ ?>