
<?php if(count($cities)>0): ?>

     <option selected disabled><?php echo e(helperTrans('admin.Now Select City')); ?></option>
    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php else: ?>


    <option selected disabled><?php echo e(helperTrans('api.Select Another governorate')); ?></option>


<?php endif; ?>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/doctor/parts/cities.blade.php ENDPATH**/ ?>