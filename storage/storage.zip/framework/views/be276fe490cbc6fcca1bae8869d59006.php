<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('select_providers.update',$row->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-4">


        <input type="hidden" name="id" value="<?php echo e($row->id); ?>">





        <?php $__currentLoopData = languages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                <!--begin::Label-->
                <label for="name_<?php echo e($language->abbreviation); ?>" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                    <span class="required mr-1"><?php echo e(helperTrans('admin.name')); ?>(<?php echo e($language->abbreviation); ?>)</span>
                    <span class="red-star">*</span>
                </label>

                <!--end::Label-->
                <input id="name_<?php echo e($language->abbreviation); ?>" required type="text" class="form-control form-control-solid"
                       placeholder="" name="name[<?php echo e($language->abbreviation); ?>]" value="<?php echo e($row->getTranslation('name', $language->abbreviation)); ?>"/>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="slug" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1">Slug</span>
                <span class="red-star">*</span>
            </label>

            <!--end::Label-->
            <input type="text" name="slug" id="slug" class="form-control" value="<?php echo e($row->slug); ?>"  >
        </div>


    </div>
</form>

<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/selectProvider/parts/edit.blade.php ENDPATH**/ ?>