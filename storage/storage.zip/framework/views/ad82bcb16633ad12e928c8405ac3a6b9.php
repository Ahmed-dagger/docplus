<meta charset="utf-8" />
<title><?php echo $__env->yieldContent('title'); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
<meta content="Themesbrand" name="author" />
<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo e(get_file(setting()->fave_icon)); ?>">

<!-- Layout config Js -->
<script src="<?php echo e(url('assets')); ?>/dashboard/js/layout.js"></script>
<!-- Bootstrap Css -->
<link href="<?php echo e(url('assets')); ?>/dashboard/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo e(url('assets')); ?>/dashboard/css/icons.min.css" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo e(url('assets')); ?>/dashboard/css/app.min.css" rel="stylesheet" type="text/css" />
<!-- custom Css-->
<link href="<?php echo e(url('assets')); ?>/dashboard/css/custom.min.css" rel="stylesheet" type="text/css" />
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="<?php echo e(url('assets')); ?>/dashboard/backEndFiles/alertify/css/alertify.min.css" />
<!-- include a theme -->
<link rel="stylesheet" href="<?php echo e(url('assets')); ?>/dashboard/backEndFiles/alertify/css/themes/default.min.css" />


<?php echo $__env->make('layouts.loader.loaderCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/Auth/layouts/assets/css.blade.php ENDPATH**/ ?>