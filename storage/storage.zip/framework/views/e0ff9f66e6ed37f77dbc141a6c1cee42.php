<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('doctors_branches.store',$doctor->id)); ?>">
    <?php echo csrf_field(); ?>
    <div class="row g-4">


        <div class="form-group">
            <label for="image" class="form-control-label"><?php echo e(helperTrans('admin.image')); ?> </label>
            <input id="image" type="file" class="dropify" name="image" data-default-file="<?php echo e(get_file()); ?>" accept="image/*"/>
            <span class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
        </div>


        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="name" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.name')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <input id="name" required type="text" class="form-control form-control-solid" placeholder="" name="name" value=""/>
        </div>


        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="phone" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"> <?php echo e(helperTrans('admin.Phone')); ?></span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input id="phone" type="text" class="form-control form-control-solid" placeholder=" " name="phone" value=""/>
        </div>

        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="latitude" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"> <?php echo e(helperTrans('admin.Latitude')); ?></span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input id="latitude" type="text" class="form-control form-control-solid" placeholder=" " name="latitude"
                   value=""/>
        </div>

        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="longitude" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"> <?php echo e(helperTrans('admin.Longitude')); ?></span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input id="longitude" type="text" class="form-control form-control-solid" placeholder=" " name="longitude"
                   value=""/>
        </div>



        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="location" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"> <?php echo e(helperTrans('admin.Location')); ?></span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input id="location" type="text" class="form-control form-control-solid" placeholder=" " name="location" value=""/>
        </div>

        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="price" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"> <?php echo e(helperTrans('admin.Price')); ?></span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input id="price" type="number" class="form-control form-control-solid" placeholder=" " name="price" value=""/>
        </div>





        <?php $__currentLoopData = languages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <div class="col-sm-6 pb-3 p-2">
                <label for="about_<?php echo e($language->abbreviation); ?>" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                    <span class="required mr-1">  <?php echo e(helperTrans('admin.About')); ?>  (<?php echo e($language->abbreviation); ?>)      </span>
                </label>
                <textarea name="about[<?php echo e($language->abbreviation); ?>]" id="about_<?php echo e($language->abbreviation); ?>" class="form-control " rows="5" placeholder=""></textarea>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





    </div>
</form>

<script>
    $('.dropify').dropify();
    $(document).ready(function () {
        $('.js-example-basic-multiple').select2();
    });
</script>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/doctorBranch/parts/create.blade.php ENDPATH**/ ?>