<!DOCTYPE html>
<html>
<head>
    <title>Password Reset OTP</title>
</head>
<body>
    <h1>Welcome to Our Application</h1>
    <p>Your OTP for password reset is: <strong><?php echo e($otpCode); ?></strong></p>
    <p>This OTP is valid for one hour.</p>
</body>
</html>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/emails/sendOtp.blade.php ENDPATH**/ ?>