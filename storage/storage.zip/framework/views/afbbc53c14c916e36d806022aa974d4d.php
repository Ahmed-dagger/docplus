<!-- ========== App Menu ========== -->

<div class="app-menu navbar-menu">
    <!-- LOGO -->
    <div class="navbar-brand-box">
        <!-- Dark Logo-->
        <a href="<?php echo e(route('admin.index')); ?>" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="<?php echo e(get_file(setting()->logo_header)); ?>" alt="" height="22">
                    </span>
            <span class="logo-lg">
                        <img src="<?php echo e(get_file(setting()->logo_header)); ?>" alt="" height="40">
                    </span>
        </a>
        <!-- Light Logo-->
        <a href="<?php echo e(route('admin.index')); ?>" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="<?php echo e(get_file(setting()->logo_header)); ?>" alt="" height="22">
                    </span>
            <span class="logo-lg">
                        <img src="<?php echo e(get_file(setting()->logo_header)); ?>" alt="" height="40">
                    </span>
        </a>
        <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover"
                id="vertical-hover">
            <i class="ri-record-circle-line"></i>
        </button>
    </div>

    <div id="scrollbar">
        <div class="container-fluid">

            <div id="two-column-menu">
            </div>
            <ul class="navbar-nav" id="navbar-nav">

                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('admin.index')); ?>">
                        <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards"> <?php echo e(helperTrans('admin.Dashboard')); ?></span>
                    </a>
                </li>

                <!-- end Dashboard Menu -->
                <?php if(auth()->guard('admin')->user()->hasPermission('languages_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('languages.index')); ?>">
                        <i class="fa fa-language"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Languages')); ?> </span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('roles_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('roles.index')); ?>">
                        <i class="fa fa-user-secret"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Roles')); ?> </span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('admins_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('admins.index')); ?>">
                        <i class="fa fa-user-secret"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Admins')); ?> </span>
                    </a>
                </li>
                <?php endif; ?>
                <!-- end Dashboard Menu -->




























                <!-- Start Main Settings -->
                <?php if(auth()->guard('admin')->user()->hasPermission('settings_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="#main_settings" data-bs-toggle="collapse" role="button"
                       aria-expanded="false" aria-controls="reports">
                        <i class="fa fa-user-md"></i>
                        <span data-key="t-apps">General Main Setting</span>
                    </a>
                    <div class="collapse menu-dropdown" id="main_settings">
                        <ul class="nav nav-sm flex-column">
                            <?php if(auth()->guard('admin')->user()->hasPermission('settings_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('main_otp.index')); ?>">
                                    <span data-key="t-dashboards">OTP Providers</span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>
                <?php endif; ?>
                <!-- End Main Settings -->
                <!-- end Patients Menu -->
                <?php if(auth()->guard('admin')->user()->hasPermission('doctors_read') || auth()->guard('admin')->user()->hasPermission('provider_types_read') || auth()->guard('admin')->user()->hasPermission('providers_read') || auth()->guard('admin')->user()->hasPermission('laboratories_read') || auth()->guard('admin')->user()->hasPermission('analysis_read') || auth()->guard('admin')->user()->hasPermission('radiology_centers_read') || auth()->guard('admin')->user()->hasPermission('insurance_people_read') || auth()->guard('admin')->user()->hasPermission('insurance_companies_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="#providers" data-bs-toggle="collapse" role="button"
                       aria-expanded="false" aria-controls="reports">
                        <i class="fa fa-user-md"></i>
                        <span data-key="t-apps"><?php echo e(helperTrans('admin.Providers')); ?>  </span>
                    </a>
                    <div class="collapse menu-dropdown" id="providers">
                        <ul class="nav nav-sm flex-column">
                            <?php if(auth()->guard('admin')->user()->hasPermission('doctors_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('doctors.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Doctors')); ?></span>
                                </a>
                            </li>
                            <?php endif; ?>

                            <?php if(auth()->guard('admin')->user()->hasPermission('provider_types_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('provider_types.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Provider Types')); ?></span>
                                </a>
                            </li>
                            <?php endif; ?>

                            

                            <?php if(auth()->guard('admin')->user()->hasPermission('laboratories_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('laboratories.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Laboratories')); ?></span>
                                </a>
                            </li>

                            <?php endif; ?>

                            <?php if(auth()->guard('admin')->user()->hasPermission('analysis_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('analysis.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Analysis')); ?></span>
                                </a>
                            </li>

                            <?php endif; ?>

                            <?php if(auth()->guard('admin')->user()->hasPermission('radiology_centers_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('radiology_centers.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Radiology Center')); ?></span>
                                </a>
                            </li>
                            <?php endif; ?>

                            <?php if(auth()->guard('admin')->user()->hasPermission('pharmacies_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('pharmacies.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Pharmacies')); ?> </span>
                                </a>
                            </li> <!-- end Dashboard Menu -->
                            <?php endif; ?>
            
                            <?php if(auth()->guard('admin')->user()->hasPermission('hospitals_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('hospitals.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Hospitals')); ?> </span>
                                </a>
                            </li> <!-- end Dashboard Menu -->
                            <?php endif; ?>
                
                            <?php if(auth()->guard('admin')->user()->hasPermission('radiology_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('radiology.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Radiology')); ?> </span>
                                </a>
                            </li> <!-- end Dashboard Menu -->
                            <?php endif; ?>



                        </ul>
                    </div>
                </li>
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('main_services_read') || auth()->guard('admin')->user()->hasPermission('package_read') || auth()->guard('admin')->user()->hasPermission('specializations_read') || auth()->guard('admin')->user()->hasPermission('experiences_read') || auth()->guard('admin')->user()->hasPermission('nationalities_read') || auth()->guard('admin')->user()->hasPermission('governorates_read') || auth()->guard('admin')->user()->hasPermission('cities_read') || auth()->guard('admin')->user()->hasPermission('families_read')): ?>

                <li class="nav-item">
                    <a class="nav-link menu-link" href="#master_data" data-bs-toggle="collapse" role="button"
                       aria-expanded="false" aria-controls="reports">
                        <i class="fa fa-list"></i>
                        <span data-key="t-apps">       <?php echo e(helperTrans('admin.Master Data')); ?>  </span>
                    </a>
                    <div class="collapse menu-dropdown" id="master_data">
                        <ul class="nav nav-sm flex-column">
                            <?php if(auth()->guard('admin')->user()->hasPermission('main_services_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('main_services.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Main Services')); ?></span>
                                </a>
                            </li>
                            <?php endif; ?>

                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('categories.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Categories')); ?></span>
                                </a>
                            </li>

                            <?php if(auth()->guard('admin')->user()->hasPermission('package_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('packages.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Package')); ?></span>
                                </a>
                            </li>
                            <?php endif; ?>

                            <?php if(auth()->guard('admin')->user()->hasPermission('specializations_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('specializations.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Specializations')); ?></span>
                                </a>
                            </li>
                            <?php endif; ?>

                            <?php if(auth()->guard('admin')->user()->hasPermission('experiences_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link"
                                   href="<?php echo e(route('experiences.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Experience')); ?></span>
                                </a>
                            </li>
                            <?php endif; ?>




                            <?php if(auth()->guard('admin')->user()->hasPermission('nationalities_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('nationalities.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Nationalities')); ?> </span>
                                </a>
                            </li>
                            <?php endif; ?>

                            <?php if(auth()->guard('admin')->user()->hasPermission('governorates_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('governorates.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Governorates')); ?> </span>
                                </a>
                            </li>
                            <?php endif; ?>

                            <?php if(auth()->guard('admin')->user()->hasPermission('cities_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('cities.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Cities')); ?> </span>
                                </a>
                            </li>
                            <?php endif; ?>


                            <?php if(auth()->guard('admin')->user()->hasPermission('families_read')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('families.index')); ?>">
                                     <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Families')); ?> </span>
                                </a>
                            </li>
                            <?php endif; ?>

         
            

                        </ul>
                    </div>
                </li>

                <?php endif; ?>
                <?php if(auth()->guard('admin')->user()->hasPermission('insurance_people_read')): ?>
                    <li class="nav-item">
                        <a class="nav-link menu-link"
                        href="<?php echo e(route('insurance_people.index')); ?>">
                        <i class="fa-solid fa-users"></i><span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Insurance People')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('insurance_companies_read')): ?>
                    <li class="nav-item">
                        <a class="nav-link menu-link" href="<?php echo e(route('insurance_companies.index')); ?>">
                            <i class="fa-solid fa-pills"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Insurance Company')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>




















































                <li class="nav-item">
                    <a class="nav-link menu-link" href="#gc" data-bs-toggle="collapse" role="button"
                       aria-expanded="false" aria-controls="reports">
                        <i class="fa fa-list"></i>
                        <span data-key="t-apps">       <?php echo e(helperTrans('admin.GC')); ?>  </span>
                    </a>
                    <div class="collapse menu-dropdown" id="gc">
                        <ul class="nav nav-sm flex-column">


                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('gc_medication_types.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Gc Medication Type')); ?> </span>
                                </a>
                            </li>



                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('gc_blood_sugar_units.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Gc Blood Sugar Units')); ?> </span>
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('gc_blood_sugar_times.index')); ?>">
                                    <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Gc Blood Sugar Times')); ?> </span>
                                </a>
                            </li>











                        </ul>
                    </div>
                </li>


                <?php if(auth()->guard('admin')->user()->hasPermission('types_read')): ?>
                    <li class="nav-item">
                        <a class="nav-link menu-link" href="<?php echo e(route('types.index')); ?>">
                            <i class="fa fa-file"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Types')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('vouchers_read')): ?>
                    <li class="nav-item">
                        <a class="nav-link menu-link" href="<?php echo e(route('vouchers.index')); ?>">
                            <i class="fa fa-code"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Voucher')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>


                <?php if(auth()->guard('admin')->user()->hasPermission('areas_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('areas.index')); ?>">
                        <i class="fa fa-area-chart"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Areas')); ?> </span>
                    </a>
                </li>
                <?php endif; ?>



                <?php if(auth()->guard('admin')->user()->hasPermission('employees_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('employees.index')); ?>">
                        <i class="fa fa-users"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Employees')); ?> </span>
                    </a>
                </li>
                <?php endif; ?>



                <?php if(auth()->guard('admin')->user()->hasPermission('patients_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('patients.index')); ?>">
                        <i class="fa fa-heartbeat"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Patients')); ?> </span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('days_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('days.index')); ?>">
                        <i class="fa fa-calendar-day"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Days')); ?> </span>
                    </a>
                </li>
                <?php endif; ?>


                <?php if(auth()->guard('admin')->user()->hasPermission('sliders_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('sliders.index')); ?>">
                        <i class="fa fa-sliders"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Sliders')); ?> </span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('patient_subscribes_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('patient_subscribes.index')); ?>">
                        <i class="fa fa-bell"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Patient Subscribe')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('medication_ways_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('medication_ways.index')); ?>">
                        <i class="fa-solid fa-pills"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Medication Ways')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('medication_units_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('medication_units.index')); ?>">
                        <i class="fa fa-balance-scale"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Medication Units')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('solution_types_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('solution_types.index')); ?>">
                        <i class="fa fa-question-circle"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Solution Types')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('solution_priorities_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('solution_priorities.index')); ?>">
                        <i class="fa fa-question-circle"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Solution Priorities')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>


                <?php if(auth()->guard('admin')->user()->hasPermission('diagnoses_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('diagnoses.index')); ?>">
                        <i class="fas fa-diagnoses"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Diagnoses')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>


                <?php if(auth()->guard('admin')->user()->hasPermission('bookings_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('bookings.index')); ?>">
                        <i class="fa fa-ticket"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Booking')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>


    


                <?php if(auth()->guard('admin')->user()->hasPermission('request_bookings_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('request_bookings.index')); ?>">
                        <i class="fa fa-ticket"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Request Booking')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>


                <?php if(auth()->guard('admin')->user()->hasPermission('notifications_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('notifications.index')); ?>">
                        <i class="fa fa-bell"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Notifications')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>


                <?php if(auth()->guard('admin')->user()->hasPermission('select_providers_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('select_providers.index')); ?>">
                        <i class="fa fa-cog"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Select Providers')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>


         

                <?php if(auth()->guard('admin')->user()->hasPermission('signs_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('signs.index')); ?>">
                        <i class="fa-solid fa-disease"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Sign')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('chronic_diseases_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('chronic_diseases.index')); ?>">
                        <i class="fa-solid fa-disease"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Chronic Diseases')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('pmedical_operations_read')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('medical_operations.index')); ?>">
                        <i class="fa-solid fa-disease"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Medical Operation')); ?> </span>
                    </a>
                </li> <!-- end Dashboard Menu -->
                <?php endif; ?>

                <?php if(auth()->guard('admin')->user()->hasPermission('settings_read')): ?>
                <li class="nav-item">
                        <a class="nav-link menu-link" href="<?php echo e(route('settings.index')); ?>">
                            <i class="fa fa-cog"></i> <span data-key="t-dashboards">  <?php echo e(helperTrans('admin.Settings')); ?> </span>
                        </a>
                    </li> <!-- end Dashboard Menu -->
                <?php endif; ?>

            </ul>
        </div>
        <!-- Sidebar -->
    </div>

    <div class="sidebar-background"></div>
</div>
<!-- Left Sidebar End -->
<!-- Vertical Overlay-->


<div class="vertical-overlay"></div>




<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/layouts/inc/sidebar.blade.php ENDPATH**/ ?>