<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('admins.update',$admin->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-4">


        <input type="hidden" name="id" value="<?php echo e($admin->id); ?>">

        <div class="form-group">
            <label for="name" class="form-control-label"><?php echo e(helperTrans('admin.image')); ?> </label>
            <input type="file" class="dropify" name="image" data-default-file="<?php echo e(get_file($admin->image)); ?>"
                   accept="image/*"/>
            <span
                class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
        </div>
        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.name')); ?></span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input type="text" required class="form-control form-control-solid" placeholder=" " name="name"
                   value="<?php echo e($admin->name); ?>"/>
        </div>

        <!--end::Input group-->
        <!--begin::Input group-->
        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"> <?php echo e(helperTrans('admin.email')); ?></span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input type="email" required class="form-control form-control-solid"
                   placeholder="  <?php echo e(helperTrans('admin.email')); ?>"
                   name="email" value="<?php echo e($admin->email); ?>"/>
        </div>

        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="phone" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"> Phone</span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input id="phone" type="text" class="form-control form-control-solid" placeholder=" " name="phone"
                   value="<?php echo e($admin->phone); ?>"/>
        </div>

        
        <div class="form-group">
            <label>Roles <span class="text-danger">*</span></label>
            <select name="role_id" class="form-control select2" required>
                <option value="">Choose Role</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e($admin->hasRole($role->name) ? 'selected' : ''); ?>><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"> <?php echo e(helperTrans('admin.password')); ?></span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input type="password" class="form-control form-control-solid" placeholder="  " name="password"
                   value=""/>
        </div>



        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="is_active" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1">Is Active</span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <select class="form-control" id="is_active" name="is_active">

                <option <?php if($admin->is_active==1): ?> selected <?php endif; ?> value="1">Active</option>
                <option <?php if($admin->is_active==0): ?> selected <?php endif; ?> value="0">Not Active</option>

            </select>
        </div>




    </div>
</form>
<script>
    $('.dropify').dropify();
    $(document).ready(function () {
        $('.js-example-basic-multiple').select2();
    });
</script>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/admin/parts/edit.blade.php ENDPATH**/ ?>