<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('categories.update',$row->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-4">


        <input type="hidden" name="id" value="<?php echo e($row->id); ?>">


        <div class="form-group">
            <label for="icon" class="form-control-label"><?php echo e(helperTrans('admin.Icon')); ?> </label>
            <input type="file" id="icon" class="dropify" name="icon" data-default-file="<?php echo e(get_file($row->icon)); ?>" accept="image/*"/>
            <span
                class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
        </div>


        <?php $__currentLoopData = languages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                <!--begin::Label-->
                <label for="name_<?php echo e($language->abbreviation); ?>" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                    <span class="required mr-1"><?php echo e(helperTrans('admin.name')); ?>(<?php echo e($language->abbreviation); ?>)</span>
                    <span class="red-star">*</span>
                </label>

                <!--end::Label-->
                <input id="name_<?php echo e($language->abbreviation); ?>" required type="text" class="form-control form-control-solid"
                       placeholder="" name="name[<?php echo e($language->abbreviation); ?>]" value="<?php echo e($row->getTranslation('name', $language->abbreviation)); ?>"/>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="main_service_id" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1">Main Service</span>
                <span class="red-star">*</span>
            </label>

            <!--end::Label-->
            <select class="form-control" id="main_service_id" name="main_service_id">
                <option selected disabled><?php echo e(helperTrans('admin.Select Main Service')); ?></option>

                <?php $__currentLoopData = $mainServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option <?php if($row->main_service_id==$mainService->id): ?> selected <?php endif; ?> value="<?php echo e($mainService->id); ?>"><?php echo e($mainService->name); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>


        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="slug" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1">Slug</span>
                <span class="red-star">*</span>
            </label>

            <!--end::Label-->
            <input type="text" name="slug" id="slug" class="form-control" value="<?php echo e($row->slug); ?>"  >
        </div>


    </div>
</form>


<script>
    $('.dropify').dropify();
</script>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/category/parts/edit.blade.php ENDPATH**/ ?>