<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('insurance_people.update',$row->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-4">


        <input type="hidden" name="id" value="<?php echo e($row->id); ?>">

        <div class="d-flex flex-column mb-7 fv-row col-sm-4">
            <!--begin::Label-->
            <label for="name" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.name')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <input id="name" required type="text" class="form-control form-control-solid" placeholder="" name="name" value="<?php echo e($row->name); ?>"/>
        </div>

        <!--end::Input group-->
        <!--begin::Input group-->
        <div class="d-flex flex-column mb-7 fv-row col-sm-4">
            <!--begin::Label-->
            <label for="phone" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.phone')); ?> </span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input id="phone" required type="text" class="form-control form-control-solid" placeholder=" <?php echo e(helperTrans('admin.phone')); ?>"
                   name="phone" value="<?php echo e($row->phone); ?>"/>
        </div>






        <div class="d-flex flex-column mb-7 fv-row col-sm-4">
            <!--begin::Label-->
            <label for="status_data" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Status')); ?></span>
                <span class="red-star">*</span>
            </label>

            <select class="form-control" id="status_data" name="status">

                <option <?php if($row->status=='active'): ?> selected <?php endif; ?> value="active"><?php echo e(helperTrans('admin.Active')); ?></option>
                <option <?php if($row->status=='expire'): ?> selected <?php endif; ?> value="expire"><?php echo e(helperTrans('admin.Expire')); ?></option>

            </select>
        </div>



        <div class="col-sm-12 pb-3 p-2">
            <label for="address" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1">  <?php echo e(helperTrans('admin.Address')); ?>   </span>
            </label>
            <textarea name="address" id="address" class="form-control " rows="5"
                      placeholder=""><?php echo e($row->address); ?></textarea>
        </div>




    </div>
</form>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/insurancePeople/parts/edit.blade.php ENDPATH**/ ?>