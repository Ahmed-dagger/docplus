<?php $__env->startSection('title'); ?>
    <?php echo e(helperTrans('admin.General Setting')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css" rel="stylesheet"/>

<?php $__env->stopSection(); ?>







<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header ">
            <h5 class="card-title mb-0 flex-grow-1"> <?php echo e(helperTrans('admin.General Settings')); ?> </h5>


            <form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('settings.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row my-4 g-4">




                    <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                        <label for="logo_header" class="form-control-label fs-6 fw-bold "> <?php echo e(helperTrans('admin.Logo')); ?> </label>
                        <input type="file" class="dropify" name="logo_header" data-default-file="<?php echo e(get_file($settings->logo_header)); ?>" accept="image/*"/>
                        <span class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
                    </div>


                    <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                        <label for="fave_icon" class="form-control-label fs-6 fw-bold ">  <?php echo e(helperTrans('admin.Icon')); ?>  </label>
                        <input type="file" id="fave_icon" class="dropify" name="fave_icon" data-default-file="<?php echo e(get_file($settings->fave_icon)); ?>" accept="image/*"/>
                        <span class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
                    </div>


                    <div class="d-flex flex-column mb-7 fv-row col-sm-3">
                        <label for="facebook_icon" class="form-control-label fs-6 fw-bold ">  <?php echo e(helperTrans('admin.facebook_icon')); ?>  </label>
                        <input type="file" id="facebook_icon" class="dropify" name="facebook_icon" data-default-file="<?php echo e(get_file($settings->facebook_icon)); ?>" accept="image/*"/>
                        <span class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
                    </div>
                    <div class="d-flex flex-column mb-7 fv-row col-sm-3">
                        <label for="website_icon" class="form-control-label fs-6 fw-bold ">  <?php echo e(helperTrans('admin.website_icon')); ?>  </label>
                        <input type="file" id="website_icon" class="dropify" name="website_icon" data-default-file="<?php echo e(get_file($settings->website_icon)); ?>" accept="image/*"/>
                        <span class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
                    </div>
                    <div class="d-flex flex-column mb-7 fv-row col-sm-2">
                        <label for="email_icon" class="form-control-label fs-6 fw-bold ">  <?php echo e(helperTrans('admin.email_icon')); ?>  </label>
                        <input type="file" id="email_icon" class="dropify" name="email_icon" data-default-file="<?php echo e(get_file($settings->email_icon)); ?>" accept="image/*"/>
                        <span class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
                    </div>
                    <div class="d-flex flex-column mb-7 fv-row col-sm-2">
                        <label for="phone_icon" class="form-control-label fs-6 fw-bold ">  <?php echo e(helperTrans('admin.phone_icon')); ?>  </label>
                        <input type="file" id="phone_icon" class="dropify" name="phone_icon" data-default-file="<?php echo e(get_file($settings->phone_icon)); ?>" accept="image/*"/>
                        <span class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
                    </div>

                    <div class="d-flex flex-column mb-7 fv-row col-sm-2">
                        <label for="fave_icon" class="form-control-label fs-6 fw-bold ">  <?php echo e(helperTrans('admin.google_icon')); ?>  </label>
                        <input type="file" id="google_icon" class="dropify" name="google_icon" data-default-file="<?php echo e(get_file($settings->google_icon)); ?>" accept="image/*"/>
                        <span class="form-text text-muted text-center"><?php echo e(helperTrans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
                    </div>

                    <div class="d-flex flex-column mb-7 fv-row col-sm-4">
                        <label for="facebook" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                            <span class="required mr-1">  <?php echo e(helperTrans('admin.Facebook')); ?></span>
                        </label>
                        <input id="facebook" type="text" class="form-control form-control-solid" name="facebook" value="<?php echo e($settings->facebook); ?>"/>
                    </div>

                    <div class="d-flex flex-column mb-7 fv-row col-sm-4">
                        <label for="website" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                            <span class="required mr-1">  <?php echo e(helperTrans('admin.website')); ?></span>
                        </label>
                        <input id="website" type="text" class="form-control form-control-solid" name="website" value="<?php echo e($settings->website); ?>"/>
                    </div>
                    
                    <div class="d-flex flex-column mb-7 fv-row col-sm-4">
                        <label for="facebook" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                            <span class="required mr-1">  <?php echo e(helperTrans('admin.email')); ?></span>
                        </label>
                        <input id="email" type="email" class="form-control form-control-solid" name="email" value="<?php echo e($settings->email); ?>"/>
                    </div>

                    <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                        <label for="phone" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                            <span class="required mr-1">  <?php echo e(helperTrans('admin.phone')); ?></span>
                        </label>
                        <input id="phone" type="text" class="form-control form-control-solid" name="phone" value="<?php echo e($settings->phone); ?>"/>
                    </div>


                    <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                        <label for="google" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                            <span class="required mr-1">  <?php echo e(helperTrans('admin.google')); ?></span>
                        </label>
                        <input id="google" type="text" class="form-control form-control-solid" name="google" value="<?php echo e($settings->google); ?>"/>
                    </div>

                    <div class="d-flex flex-column mb-7 fv-row col-sm-12">
                        <label for="app_name" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                            <span class="required mr-1">  <?php echo e(helperTrans('admin.App Name')); ?></span>
                        </label>
                        <input id="app_name" type="text" class="form-control form-control-solid" name="app_name" value="<?php echo e($settings->app_name); ?>"/>
                    </div>



                    <?php $__currentLoopData = languages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <div class="col-sm-6 pb-3 p-2">
                            <label for="privacy_<?php echo e($language->abbreviation); ?>" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                <span class="required mr-1">  <?php echo e(helperTrans('admin.Privacy')); ?>  (<?php echo e($language->abbreviation); ?>)      </span>
                            </label>
                            <textarea name="privacy[<?php echo e($language->abbreviation); ?>]" id="privacy_<?php echo e($language->abbreviation); ?>" class="form-control " rows="5"
                                      placeholder=""><?php echo e($settings->getTranslation('privacy', $language->abbreviation)); ?></textarea>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = languages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <div class="col-sm-6 pb-3 p-2">
                            <label for="about_<?php echo e($language->abbreviation); ?>" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                <span class="required mr-1">  <?php echo e(helperTrans('admin.about')); ?>  (<?php echo e($language->abbreviation); ?>)      </span>
                            </label>
                            <textarea name="about[<?php echo e($language->abbreviation); ?>]" id="about_<?php echo e($language->abbreviation); ?>" class="form-control " rows="5"
                                      placeholder=""><?php echo e($settings->getTranslation('about', $language->abbreviation)); ?></textarea>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                    <div class="my-4">
                        <button type="submit" class="btn btn-success"> <?php echo e(helperTrans('admin.Update')); ?></button>
                    </div>


                </div>
            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"></script>


    <script>
        $('.dropify').dropify();

    </script>


    <script>
        // CKEDITOR.replace('privacy');


    </script>
    <script>
        $(document).on('submit', "form#form", function (e) {
            e.preventDefault();

            var formData = new FormData(this);

            var url = $('#form').attr('action');
            $.ajax({
                url: url,
                type: 'POST',
                data: formData,

                complete: function () {
                },
                success: function (data) {

                    window.setTimeout(function () {

// $('#product-model').modal('hide')
                        if (data.code == 200) {
                            toastr.success(data.message)
                        } else {
                            toastr.error(data.message)
                        }
                    }, 1000);


                },
                error: function (data) {
                    if (data.status === 500) {
                        toastr.error('<?php echo e(helperTrans('admin.there is an error')); ?>')
                    }

                    if (data.status === 422) {
                        var errors = $.parseJSON(data.responseText);

                        $.each(errors, function (key, value) {
                            if ($.isPlainObject(value)) {
                                $.each(value, function (key, value) {
                                    toastr.error(value)
                                });

                            } else {

                            }
                        });
                    }
                    if (data.status == 421) {
                        toastr.error(data.message)
                    }

                },//end error method

                cache: false,
                contentType: false,
                processData: false
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.inc.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/settings/index.blade.php ENDPATH**/ ?>