<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('radiology.update',$row->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-4">


        <input type="hidden" name="id" value="<?php echo e($row->id); ?>">



    <?php $__currentLoopData = languages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="d-flex flex-column mb-7 fv-row col-sm-6">
                <!--begin::Label-->
                <label for="name_<?php echo e($language->abbreviation); ?>" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                    <span class="required mr-1"><?php echo e(helperTrans('admin.name')); ?>(<?php echo e($language->abbreviation); ?>)</span>
                    <span class="red-star">*</span>
                </label>

                <!--end::Label-->
                <input id="name_<?php echo e($language->abbreviation); ?>" required type="text" class="form-control form-control-solid"
                       placeholder="" name="name[<?php echo e($language->abbreviation); ?>]" value="<?php echo e($row->getTranslation('name', $language->abbreviation)); ?>"/>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="price" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Price')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <input type="number" id="price" class="form-control" name="price" value="<?php echo e($row->price); ?>">
        </div>




        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="radiology_center_id" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Radiology Center')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <select class="form-control" id="radiology_center_id" name="radiology_center_id">
                <option selected disabled><?php echo e(helperTrans('admin.Select Radiology')); ?></option>

                <?php $__currentLoopData = $radiology_centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $radiology_center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($row->radiology_center_id==$radiology_center->id): ?> selected <?php endif; ?> value="<?php echo e($radiology_center->id); ?>"><?php echo e($radiology_center->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>







    </div>
</form>


<script>
    $('.dropify').dropify();

</script>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/radiology/parts/edit.blade.php ENDPATH**/ ?>