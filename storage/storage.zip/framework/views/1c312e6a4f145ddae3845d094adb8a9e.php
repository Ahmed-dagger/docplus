<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('roles.update',$role->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-4">

        <div class="form-group">
            <label>Name <span class="text-danger">*</span></label>
            <input type="text" name="name" autofocus class="form-control"  value="<?php echo e(old('name', $role->name)); ?>" required>
        </div>

        <h5>Permissions <span class="text-danger">*</span></h5>

        <?php
            $models = [
                'roles',
                'admins',
                'users',
                'providers',
                'doctors',
                'laboratories',
                'analysis',
                'radiology_center',
                'insurance_people',
                'insurance_companies',
                'main_services',
                'package',
                'specializations',
                'experiences',
                'governorates',
                'cities',
                'families',
                'types',
                'areas',
                'employees',
                'patients',
                'days',
                'sliders',
                'patient_subscribe',
                'medication_ways',
                'medication_units',
                'solution_types',
                'solution_priorities',
                'diagnoses',
                'booking',
                'hospitals',
                'request_booking',
                'notifications',
                'select_providers',
                'pharmacies',
                'radiology',
                'sign',
                'chronic_diseases',
                'medical_operation',
                'vouchers',
                'settings',
            ];
        ?>

        <table class="table">
            <thead>
            <tr>
                <th>Model</th>
                <th>Permissions</th>
            </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($model); ?></td>
                        <td>

                            <?php
                                $permissionMaps = ['create', 'read', 'update', 'delete'];
                            ?>

                            <?php $__currentLoopData = $permissionMaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionMap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="animated-checkbox mx-2" style="display:inline-block;">
                                    <label class="m-0">
                                        <input type="checkbox" value="<?php echo e($model . '_' . $permissionMap); ?>" name="permissions[]" <?php echo e($role->hasPermission( $model . '_' . $permissionMap) ? 'checked' : ''); ?> class="role">
                                        <span class="label-text"><?php echo e($permissionMap); ?> </span>
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table><!-- end of table -->
    </div>
</form>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/role/parts/edit.blade.php ENDPATH**/ ?>