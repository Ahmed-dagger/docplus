<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('patients.update',$row->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-4">


        <input type="hidden" name="id" value="<?php echo e($row->id); ?>">



        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="name" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.name')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <input id="name" required type="text" class="form-control form-control-solid" placeholder="" name="name" value="<?php echo e($row->name); ?>"/>
        </div>



        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="nickname" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.nickname')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <input id="nickname" required type="text" class="form-control form-control-solid" placeholder="" name="nickname" value="<?php echo e($row->nickname); ?>"/>
        </div>

        <!--end::Input group-->
        <!--begin::Input group-->
        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="postcode" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.postcode')); ?> </span>
            </label>
            <!--end::Label-->
            <input id="postcode" required type="text" class="form-control form-control-solid" placeholder=" <?php echo e(helperTrans('admin.postcode')); ?>"
                   name="postcode" value="<?php echo e($row->postcode); ?>"/>
        </div>

        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="phone" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"> <?php echo e(helperTrans('admin.Phone')); ?></span>
                <span class="red-star">*</span>
            </label>
            <!--end::Label-->
            <input id="phone" type="text" class="form-control form-control-solid" placeholder=" " name="phone"
                   value="<?php echo e($row->phone); ?>"/>
        </div>


        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="refer_code" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Refer Code')); ?></span>
            </label>
            <!--end::Label-->
            <input type="text" id="refer_code" class="form-control form-control-solid" placeholder=" " name="refer_code" value="<?php echo e($row->refer_code); ?>"/>
        </div>



        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="gender" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Gender')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <select name="gender" id="gender" class="form-control">
                <option selected disabled>Select Gender</option>
                <option <?php if($row->gender=='male'): ?> selected <?php endif; ?> value="male">Male</option>
                <option <?php if($row->gender=='female'): ?> selected <?php endif; ?> value="female">Female</option>

            </select>
        </div>

        <div class="d-flex flex-column mb-7 fv-row col-sm-12">
            <!--begin::Label-->
            <label for="package_id" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Package')); ?></span>
            </label>
            <!--end::Label-->
            <select name="package_id" id="package_id" class="form-control">
                <option selected disabled>Select package</option>
                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($package->id); ?>" <?php echo e($package->id == $row->package_id ? 'selected' : ''); ?>><?php echo e($package->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="email" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Email')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <input type="email" name="email" id="email" class="form-control" value="<?php echo e($row->email); ?>">
        </div>

        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="password" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Password')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <input type="password" name="password" id="password" class="form-control">
        </div>






        <div class="d-flex flex-column mb-7 fv-row col-sm-4">
            <!--begin::Label-->
            <label for="status_data" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Status')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <select name="status" id="status_data" class="form-control">
                <option selected disabled>Select Status</option>
                <option <?php if($row->status==1): ?> selected <?php endif; ?> value="1">Active</option>
                <option <?php if($row->status==0): ?> selected <?php endif; ?> value="0">Not Active</option>

            </select>
        </div>




        <div class="d-flex flex-column mb-7 fv-row col-sm-4">
            <!--begin::Label-->
            <label for="nationality_id" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.Nationality')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <select name="nationality_id" id="nationality_id" class="form-control">
                <option selected disabled>Select Nationality</option>
                <?php $__currentLoopData = $nationalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($row->nationality_id==$nationality->id): ?> selected <?php endif; ?> value="<?php echo e($nationality->id); ?>"><?php echo e($nationality->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>





        <div class="d-flex flex-column mb-7 fv-row col-sm-4">
            <!--begin::Label-->
            <label for="city_id" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(helperTrans('admin.City')); ?> <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <select name="city_id" id="city_id" class="form-control">
                <option selected disabled> Select City</option>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($row->city_id==$city->id): ?> selected <?php endif; ?>  value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>




        <div class="col-sm-12 pb-3 p-2">
            <label for="address" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1">  <?php echo e(helperTrans('admin.Address')); ?>       <span class="red-star">*</span></span>
            </label>
            <textarea name="address" id="address" class="form-control " rows="5"
                      placeholder=""><?php echo e($row->address); ?></textarea>
        </div>



    </div>
</form>

<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/patient/parts/edit.blade.php ENDPATH**/ ?>