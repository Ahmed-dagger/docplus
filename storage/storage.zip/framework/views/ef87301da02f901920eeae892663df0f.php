<!DOCTYPE html>
<html>
<head>
    <title>Database Backup Email</title>
</head>
<body>
    <p>Dear user,</p>

    <p>Attached is the database backup file: <strong><?php echo e($filename); ?></strong></p>

    <p>
        You can download the file by clicking the link below:
        <a href="<?php echo e($downloadLink); ?>" download>Download Backup</a>
    </p>

    <p>Thank you!</p>
</body>
</html>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/emails/DB/export.blade.php ENDPATH**/ ?>