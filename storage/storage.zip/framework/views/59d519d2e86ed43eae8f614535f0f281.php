<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script>
                © <a href=""><?php echo e(setting()->app_name??''); ?>.
                </a>
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design & Develop by <a href=""><?php echo e(setting()->app_name??''); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/layouts/inc/footer.blade.php ENDPATH**/ ?>