
<?php if(count($sub_specializations)>0): ?>

    <option selected disabled><?php echo e(helperTrans('admin.Now Select Sub Specializations')); ?></option>
    <?php $__currentLoopData = $sub_specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($sub_specialization->id); ?>"><?php echo e($sub_specialization->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php else: ?>


    <option selected disabled><?php echo e(helperTrans('api.Select Another Specialization')); ?></option>


<?php endif; ?>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/Admin/CRUDS/doctor/parts/sub_specializations.blade.php ENDPATH**/ ?>