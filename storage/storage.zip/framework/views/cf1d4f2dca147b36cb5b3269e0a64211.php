<div class="loader-ajax" style="display: none  ; ">
    <div class="lds-grid" >
        <div></div><div></div><div></div><div></div><div></div><div></div>
        <div></div><div></div><div>
        </div>
    </div>
</div>
<div class="lds-hourglass"></div>
<?php /**PATH /home/doctoriaplus/public_html/resources/views/layouts/loader/loader.blade.php ENDPATH**/ ?>